#pragma once
#include <iostream>
#include <string>

using namespace std;
const string input_binary_folder_path = "..\\..\\..\\images\\binary\\";
const string output_folder_path = ".\\processed_image\\";
